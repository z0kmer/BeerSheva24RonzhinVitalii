package telran.queries;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

import telran.queries.entities.Game;
import telran.queries.entities.Move;
import telran.queries.services.BullsCowsServiceImpl;

public class GameServerHandler implements Runnable {
    private final Socket clientSocket;

    public GameServerHandler(Socket clientSocket) {
        this.clientSocket = clientSocket;
    }

    @Override
    public void run() {
        try (ObjectOutputStream oos = new ObjectOutputStream(clientSocket.getOutputStream());
             ObjectInputStream ois = new ObjectInputStream(clientSocket.getInputStream())) {
             
            BullsCowsServiceImpl service = new BullsCowsServiceImpl();
            while (true) {
                String command = (String) ois.readObject();
                switch (command) {
                    case "CREATE_GAME":
                        String sequence = (String) ois.readObject();
                        String creator = (String) ois.readObject();
                        String name = (String) ois.readObject();
                        Game game = service.createGame(sequence, creator, name);
                        oos.writeObject(game);
                        break;
                    case "START_GAME":
                        Long gameId = (Long) ois.readObject();
                        service.startGame(gameId);
                        oos.writeObject("Game started!");
                        break;
                    case "JOIN_GAME":
                        gameId = (Long) ois.readObject();
                        String gamer = (String) ois.readObject();
                        service.joinGame(gameId, gamer);
                        oos.writeObject("Joined game successfully.");
                        break;
                    case "MAKE_MOVE":
                        gameId = (Long) ois.readObject();
                        gamer = (String) ois.readObject();
                        String moveSequence = (String) ois.readObject();
                        Move move = service.makeMove(gameId, gamer, moveSequence);
                        oos.writeObject("Move made: " + move.toString());
                        break;
                    case "GET_MOVES":
                        gameId = (Long) ois.readObject();
                        oos.writeObject(service.getMoves(gameId));
                        break;
                    case "LIST_AVAILABLE_GAMES":
                        oos.writeObject(service.listAvailableGames());
                        break;
                    case "LIST_GAMES_WITH_WINNERS":
                        oos.writeObject(service.listGamesWithWinners());
                        break;
                    case "GET_WINNER":
                        gameId = (Long) ois.readObject();
                        oos.writeObject(service.getWinner(gameId));
                        break;
                    default:
                        oos.writeObject("Unknown command: " + command);
                }
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
