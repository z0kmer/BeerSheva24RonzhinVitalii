package telran.queries.services;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import telran.queries.entities.Game;
import telran.queries.entities.GameGamer;
import telran.queries.entities.Move;

public class BullsCowsServiceImpl {
    private EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpql-games");

    public Game createGame(String sequence, String creator, String name) {
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        Game game = new Game(sequence, creator, name);
        em.persist(game);
        em.getTransaction().commit();
        em.close();
        return game;
    }

    public void startGame(Long gameId) {
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        Game game = em.find(Game.class, gameId);
        game.setDateGame(LocalDate.now());
        em.merge(game);
        em.getTransaction().commit();
        em.close();
    }

    public void joinGame(Long gameId, String gamer) {
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        Game game = em.find(Game.class, gameId);
        GameGamer gameGamer = new GameGamer(game, gamer);
        em.persist(gameGamer);
        em.getTransaction().commit();
        em.close();
    }

    public Move makeMove(Long gameId, String gamer, String moveSequence) {
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        Game game = em.find(Game.class, gameId);
        Move move = new Move(game, gamer, moveSequence);
        int bulls = 0;
        int cows = 0;
        // Логика проверки быков и коров
        move.setBulls(bulls);
        move.setCows(cows);
        em.persist(move);
        em.getTransaction().commit();
        em.close();
        return move;
    }

    public List<Move> getMoves(Long gameId) {
        EntityManager em = emf.createEntityManager();
        List<Move> moves = em.createQuery("SELECT m FROM Move m WHERE m.game.id = :gameId", Move.class)
                .setParameter("gameId", gameId)
                .getResultList();
        em.close();
        return moves;
    }

    public List<Game> listAvailableGames() {
        EntityManager em = emf.createEntityManager();
        List<Game> games = em.createQuery("SELECT g FROM Game g WHERE g.dateGame IS NULL", Game.class)
                .getResultList();
        em.close();
        return games;
    }

    public List<Game> listGamesWithWinners() {
        EntityManager em = emf.createEntityManager();
        List<Game> games = em.createQuery("SELECT g FROM Game g WHERE g.isFinished = true", Game.class)
                .getResultList();
        em.close();
        return games;
    }

    public String getWinner(Long gameId) {
        EntityManager em = emf.createEntityManager();
        List<String> winners = em.createQuery("SELECT gg.gamer FROM GameGamer gg WHERE gg.game.id = :gameId AND gg.isWinner = true", String.class)
                .setParameter("gameId", gameId)
                .getResultList();
        em.close();
        return winners.isEmpty() ? "No winner yet" : winners.get(0);
    }
}
