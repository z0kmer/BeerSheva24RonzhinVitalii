package telran.queries;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import telran.queries.entities.Game;

public class BullsCowsRepositoryImpl {
    private EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpql-games");

    public Game save(Game game) {
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        em.persist(game);
        em.getTransaction().commit();
        em.close();
        return game;
    }

    public Game findById(Long gameId) {
        EntityManager em = emf.createEntityManager();
        Game game = em.find(Game.class, gameId);
        em.close();
        return game;
    }

    public List<Game> findAllAvailableGames() {
        EntityManager em = emf.createEntityManager();
        List<Game> games = em.createQuery("SELECT g FROM Game g WHERE g.dateGame IS NULL", Game.class).getResultList();
        em.close();
        return games;
    }

    public List<Game> findAllGamesWithWinners() {
        EntityManager em = emf.createEntityManager();
        List<Game> games = em.createQuery("SELECT g FROM Game g WHERE g.isFinished = true", Game.class).getResultList();
        em.close();
        return games;
    }

    public void update(Game game) {
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        em.merge(game);
        em.getTransaction().commit();
        em.close();
    }
}
