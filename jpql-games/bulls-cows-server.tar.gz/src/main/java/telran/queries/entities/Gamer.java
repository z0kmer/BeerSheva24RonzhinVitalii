package telran.queries.entities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Gamer implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    private String name;
    private String birthdate;

    public Gamer() {
    }

    public Gamer(String name, String birthdate) {
        this.name = name;
        this.birthdate = birthdate;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBirthdate() {
        return birthdate;
    }

    public void setBirthdate(String birthdate) {
        this.birthdate = birthdate;
    }

    @Override
    public String toString() {
        return "Gamer{" +
                "name='" + name + '\'' +
                ", birthdate='" + birthdate + '\'' +
                '}';
    }
}
