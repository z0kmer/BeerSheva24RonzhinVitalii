package telran.queries.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Move implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "game_id")
    private Game game;

    @Column(name = "gamer")
    private String gamer;

    @Column(name = "move_sequence")
    private String moveSequence;

    private int bulls;
    private int cows;

    public Move() {
    }

    public Move(Game game, String gamer, String moveSequence) {
        this.game = game;
        this.gamer = gamer;
        this.moveSequence = moveSequence;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Game getGame() {
        return game;
    }

    public void setGame(Game game) {
        this.game = game;
    }

    public String getGamer() {
        return gamer;
    }

    public void setGamer(String gamer) {
        this.gamer = gamer;
    }

    public String getMoveSequence() {
        return moveSequence;
    }

    public void setMoveSequence(String moveSequence) {
        this.moveSequence = moveSequence;
    }

    public int getBulls() {
        return bulls;
    }

    public void setBulls(int bulls) {
        this.bulls = bulls;
    }

    public int getCows() {
        return cows;
    }

    public void setCows(int cows) {
        this.cows = cows;
    }

    @Override
    public String toString() {
        return "Move{" +
                "id=" + id +
                ", game=" + game +
                ", gamer='" + gamer + '\'' +
                ", moveSequence='" + moveSequence + '\'' +
                ", bulls=" + bulls +
                ", cows=" + cows +
                '}';
    }
}
